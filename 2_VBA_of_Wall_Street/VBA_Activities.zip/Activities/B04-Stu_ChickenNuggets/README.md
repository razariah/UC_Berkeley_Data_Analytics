# Looping on through

Now it's your chance to see how quickly we can create data utilizing the power of a computer and FOR loops!

## Instructions

* Create a `For` loop that will produce the following example. The lines signify new cells.

|  A | B  |  C |
|:---:|:---:|:---:|
| I will eat | 11 | Chicken Nuggets |
| I will eat | 12 | Chicken Nuggets |
| I will eat | 13 | Chicken Nuggets |
| I will eat | 14 | Chicken Nuggets |
| I will eat | 15 | Chicken Nuggets |
| I will eat | 16 | Chicken Nuggets |
| I will eat | 17 | Chicken Nuggets |
| I will eat | 18 | Chicken Nuggets |
| I will eat | 19 | Chicken Nuggets |
| I will eat | 20 | Chicken Nuggets |

## Bonus

* If you finish early, talk to your neighbor about why you may want to use a For loop in preference to the "range" function.
